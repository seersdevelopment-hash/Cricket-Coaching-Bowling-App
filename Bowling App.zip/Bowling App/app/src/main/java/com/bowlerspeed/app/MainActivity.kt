package com.bowlerspeed.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bowlerspeed.app.data.DeliveryEntity
import com.bowlerspeed.app.data.SessionEntity
import com.bowlerspeed.app.ui.BowlerScreen
import com.bowlerspeed.app.ui.BowlerSpeedTheme
import com.bowlerspeed.app.ui.BowlerSpeedUiState
import com.bowlerspeed.app.ui.BowlerSpeedViewModel
import com.bowlerspeed.app.ui.CalibrationDraft
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BowlerSpeedTheme {
                BowlerSpeedApp()
            }
        }
    }
}

@Composable
private fun BowlerSpeedApp(viewModel: BowlerSpeedViewModel = viewModel()) {
    val state by viewModel.uiState
    val canNavigateBack = state.screen != BowlerScreen.Home

    Scaffold(
        topBar = {
            AppBar(
                title = when (state.screen) {
                    BowlerScreen.Home -> "Bowler Speed"
                    BowlerScreen.Setup -> "Camera setup"
                    BowlerScreen.Calibration -> "Calibration"
                    BowlerScreen.Recording -> "Record delivery"
                    BowlerScreen.Result -> "Ball result"
                    BowlerScreen.Summary -> "Session summary"
                    BowlerScreen.History -> "History"
                },
                canNavigateBack = canNavigateBack,
                onBack = {
                    if (state.screen == BowlerScreen.History) {
                        viewModel.goTo(BowlerScreen.Home)
                    } else {
                        viewModel.goTo(BowlerScreen.Home)
                    }
                },
                onHistory = { viewModel.goTo(BowlerScreen.History) }
            )
        }
    ) { padding ->
        Surface(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            when (state.screen) {
                BowlerScreen.Home -> HomeScreen(
                    state = state,
                    onDraftChange = viewModel::updateSessionDraft,
                    onStartSession = viewModel::startSession,
                    onOpenSession = { viewModel.openSession(it) }
                )

                BowlerScreen.Setup -> SetupScreen(
                    onContinue = { viewModel.goTo(BowlerScreen.Calibration) }
                )

                BowlerScreen.Calibration -> CalibrationScreen(
                    draft = state.calibrationDraft,
                    onDraftChange = viewModel::updateCalibrationDraft,
                    onSave = viewModel::saveCalibration
                )

                BowlerScreen.Recording -> RecordingScreen(
                    state = state,
                    createVideoFile = viewModel::createVideoFile,
                    onClipRecorded = viewModel::processRecordedClip,
                    onError = viewModel::showRecordingError
                )

                BowlerScreen.Result -> ResultScreen(
                    state = state,
                    onNextBall = viewModel::newBall,
                    onSummary = { viewModel.goTo(BowlerScreen.Summary) }
                )

                BowlerScreen.Summary -> SummaryScreen(
                    state = state,
                    onRecordAnother = viewModel::newBall
                )

                BowlerScreen.History -> HistoryScreen(
                    sessions = state.sessions,
                    onOpenSession = { viewModel.openSession(it) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppBar(
    title: String,
    canNavigateBack: Boolean,
    onBack: () -> Unit,
    onHistory: () -> Unit
) {
    TopAppBar(
        title = {
            Text(
                text = title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
        },
        actions = {
            IconButton(onClick = onHistory) {
                Icon(Icons.Default.History, contentDescription = "History")
            }
        }
    )
}

@Composable
private fun HomeScreen(
    state: BowlerSpeedUiState,
    onDraftChange: (com.bowlerspeed.app.ui.SessionDraft) -> Unit,
    onStartSession: () -> Unit,
    onOpenSession: (Long) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Start a bowling session",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = state.sessionDraft.coachName,
                    onValueChange = { onDraftChange(state.sessionDraft.copy(coachName = it)) },
                    label = { Text("Coach name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = state.sessionDraft.location,
                    onValueChange = { onDraftChange(state.sessionDraft.copy(location = it)) },
                    label = { Text("Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = state.sessionDraft.notes,
                    onValueChange = { onDraftChange(state.sessionDraft.copy(notes = it)) },
                    label = { Text("Notes") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = onStartSession,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Create session")
                }
            }
        }

        if (state.sessions.isNotEmpty()) {
            item {
                Text(
                    text = "Recent sessions",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(state.sessions.take(4), key = { it.id }) { session ->
                SessionRow(session = session, onClick = { onOpenSession(session.id) })
            }
        }
    }
}

@Composable
private fun SetupScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = "Place the phone on a tripod behind the bowling end and align the pitch down the centre of the preview.",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        SetupCheck("Rear camera faces the pitch from behind the stumps")
        SetupCheck("Tripod is stable and roughly waist to chest height")
        SetupCheck("Stumps and popping crease stay visible in frame")
        SetupCheck("The bowler will not block the ball immediately after release")
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Continue to calibration")
        }
    }
}

@Composable
private fun SetupCheck(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
        Text(text = text, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun CalibrationScreen(
    draft: CalibrationDraft,
    onDraftChange: (CalibrationDraft) -> Unit,
    onSave: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = "Tune the setup using known pitch and stump dimensions.",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        CalibrationSlider(
            label = "Camera height",
            value = draft.cameraHeightM,
            suffix = "m",
            range = 0.6f..2.2f,
            onValueChange = { onDraftChange(draft.copy(cameraHeightM = it)) }
        )
        CalibrationSlider(
            label = "Distance behind stumps",
            value = draft.distanceBehindStumpsM,
            suffix = "m",
            range = 3.0f..13.0f,
            onValueChange = { onDraftChange(draft.copy(distanceBehindStumpsM = it)) }
        )
        CalibrationSlider(
            label = "Pitch scale",
            value = draft.pitchScaleMetersPerPixel,
            suffix = "m/px",
            range = 0.015f..0.065f,
            onValueChange = { onDraftChange(draft.copy(pitchScaleMetersPerPixel = it)) }
        )
        PlacementStatus(draft)
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onSave,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Save calibration")
        }
    }
}

@Composable
private fun CalibrationSlider(
    label: String,
    value: Float,
    suffix: String,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.Medium)
            Text("${"%.3f".format(value)} $suffix")
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range
        )
    }
}

@Composable
private fun PlacementStatus(draft: CalibrationDraft) {
    val color = if (draft.isRecommended) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.secondary
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.11f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.Speed, contentDescription = null, tint = color)
            Text(
                text = draft.placementStatus,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@Composable
private fun RecordingScreen(
    state: BowlerSpeedUiState,
    createVideoFile: (Long, Int) -> File,
    onClipRecorded: (File) -> Unit,
    onError: (String) -> Unit
) {
    val session = state.currentSession ?: return
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            onError("Camera permission is required to record deliveries.")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Ball ${state.nextBallNumber}", style = MaterialTheme.typography.headlineSmall)
                Text(session.location, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            ConfidenceBadge("Mock analysis")
        }

        if (hasCameraPermission) {
            CameraRecorder(
                sessionId = session.id,
                ballNumber = state.nextBallNumber,
                isProcessing = state.isProcessing,
                createVideoFile = createVideoFile,
                onClipRecorded = onClipRecorded,
                onError = onError
            )
        } else {
            PermissionPanel(onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) })
        }

        state.errorMessage?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.secondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun CameraRecorder(
    sessionId: Long,
    ballNumber: Int,
    isProcessing: Boolean,
    createVideoFile: (Long, Int) -> File,
    onClipRecorded: (File) -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember(context) { ContextCompat.getMainExecutor(context) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }
    var activeFile by remember { mutableStateOf<File?>(null) }
    val isRecording = activeRecording != null

    DisposableEffect(lifecycleOwner) {
        onDispose {
            activeRecording?.close()
            cameraProvider?.unbindAll()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                val previewView = PreviewView(viewContext).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                val providerFuture = ProcessCameraProvider.getInstance(viewContext)
                providerFuture.addListener(
                    {
                        val provider = providerFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val recorder = Recorder.Builder()
                            .setQualitySelector(
                                QualitySelector.from(
                                    Quality.HD,
                                    FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                                )
                            )
                            .build()
                        val capture = VideoCapture.withOutput(recorder)
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            capture
                        )
                        cameraProvider = provider
                        videoCapture = capture
                    },
                    executor
                )
                previewView
            }
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                enabled = !isProcessing && videoCapture != null,
                onClick = {
                    if (isRecording) {
                        activeRecording?.stop()
                    } else {
                        val outputFile = createVideoFile(sessionId, ballNumber)
                        activeFile = outputFile
                        val outputOptions = FileOutputOptions.Builder(outputFile).build()
                        val pendingRecording = videoCapture?.output
                            ?.prepareRecording(context, outputOptions)
                        activeRecording = pendingRecording?.start(executor) { event ->
                            when (event) {
                                is VideoRecordEvent.Finalize -> {
                                    val finishedFile = activeFile
                                    activeRecording = null
                                    activeFile = null
                                    if (event.hasError()) {
                                        onError(event.cause?.message ?: "Recording failed.")
                                    } else if (finishedFile != null) {
                                        onClipRecorded(finishedFile)
                                    }
                                }
                            }
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Videocam,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(if (isRecording) "Stop recording" else "Record")
            }
        }
    }

    if (isProcessing) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Text("Processing delivery", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PermissionPanel(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(42.dp))
        Text("Camera permission is needed for the preview and delivery recording.")
        Button(onClick = onRequestPermission) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Enable camera")
        }
    }
}

@Composable
private fun ResultScreen(
    state: BowlerSpeedUiState,
    onNextBall: () -> Unit,
    onSummary: () -> Unit
) {
    val delivery = state.lastDelivery ?: return
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        SpeedReadout(delivery)
        ResultDetail("Ball", delivery.ballNumber.toString())
        ResultDetail("Confidence", "${(delivery.confidence * 100).roundToInt()}%")
        ResultDetail("Replay file", File(delivery.videoPath).name)
        ConfidenceNote(delivery.confidence)
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = onSummary,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.History, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Summary")
            }
            Button(
                onClick = onNextBall,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Next ball")
            }
        }
    }
}

@Composable
private fun SummaryScreen(
    state: BowlerSpeedUiState,
    onRecordAnother: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        val session = state.currentSession
        Text(
            text = session?.location ?: "Session",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "${state.deliveries.size} deliveries captured",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (state.deliveries.isNotEmpty()) {
            val best = state.deliveries.maxBy { it.speedKph }
            ResultDetail("Fastest", "${best.speedKph.roundToInt()} kph")
            ResultDetail("Average", "${state.deliveries.map { it.speedKph }.average().roundToInt()} kph")
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.deliveries, key = { it.id }) { delivery ->
                DeliveryRow(delivery)
            }
        }
        Button(
            onClick = onRecordAnother,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Videocam, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Record another ball")
        }
    }
}

@Composable
private fun HistoryScreen(
    sessions: List<SessionEntity>,
    onOpenSession: (Long) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (sessions.isEmpty()) {
            item {
                Text("No sessions yet.")
            }
        }
        items(sessions, key = { it.id }) { session ->
            SessionRow(session = session, onClick = { onOpenSession(session.id) })
        }
    }
}

@Composable
private fun SpeedReadout(delivery: DeliveryEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Ball ${delivery.ballNumber}",
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f)
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = delivery.speedKph.roundToInt().toString(),
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "kph",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

@Composable
private fun ConfidenceNote(confidence: Double) {
    val label = if (confidence < 0.55) {
        "Low confidence. Review the clip before using this speed."
    } else {
        "Confidence is high enough for a field-test result."
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LinearProgressIndicator(
            progress = { confidence.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ResultDetail(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DeliveryRow(delivery: DeliveryEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Ball ${delivery.ballNumber}", fontWeight = FontWeight.SemiBold)
                Text(
                    "${(delivery.confidence * 100).roundToInt()}% confidence",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "${delivery.speedKph.roundToInt()} kph",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SessionRow(session: SessionEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(session.location, fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDate(session.dateEpochMillis)} - ${session.coachName}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Default.PlayArrow, contentDescription = null)
        }
    }
}

@Composable
private fun ConfidenceBadge(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = MaterialTheme.colorScheme.tertiary,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

private fun formatDate(epochMillis: Long): String {
    return SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(epochMillis))
}
